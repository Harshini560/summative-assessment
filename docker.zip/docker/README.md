# Build a Docker image using Maven and Spring Boot

Source code to accompany the article on medium.com